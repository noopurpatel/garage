<?php

$con=mysqli_connect("localhost","root","","garage_management_system");

if(mysqli_connect_errno())
{
	echo "Failed to connect".mysqli_connect_error();
}

?>