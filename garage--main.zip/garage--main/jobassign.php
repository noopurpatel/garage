<!DOCTYPE HTML>
<html>
<head>
<link href="Garage/css/style.css" rel="stylesheet">
<title>Job Assign</title>
</head>
<body>
<div class="wrap">
		<div class="header">
			<img style="position:relative; left:400px; top:10px;" src="Garage/images/logo2.png"/>
		</div>
	<form  method="post" action=" ">
			<input type='submit' name='logout' value='Log Out' style='position:absolute; top:5%; left:87%; background-color:ash; color:black; width:100px; height:30px; border-radius:45px; border-style:none;'>;
				
		</form>
  <div class="header-bottom" style="position:relative; top:20px;">
			<div class="menu">
				<li><a href="SupHome.php">Home</a></li>
				<li class="active"><a href="appointmentsuamm.html">Job Assign</a></li>
			</div>
			<div class="clear"></div>
  </div>
  <form method="post" action=" ">
  <input type="reset" name="Clearbotton" value="Reset" style="background-color:grey; color:black; width:100px; height:30px; border-radius:45px; border-style:none; position:absolute; top:550px; left:480px">
  
</td>
</div>
    
    <tr>
		<td style=" position:absolute; top:1000px; right:35%;"><input type="submit" name="assign" value="Submit" style="background-color:black; color:white; width:100px; height:30px; border-radius:45px; border-style:none; position:absolute; top:550px; left:655px"></td>
		</tr>
	</table>

    <tr>
		<td style=" position:absolute; bottom:10%; right:45%;"></td>
</tr>
	</table>



<tr>
		<td style=" position:absolute; top:70%; left:35%;"><table width="800" border="3">
		  <tbody>
</tbody>
  </table>		  <input type="text" name="des" placeholder="  Enter Repair Details" size="50%" style="height:30px; border-radius:45px;  border-style:none; font-size:15px; position:absolute; top:400px; left:300px"></td>"></td>
		</tr>
        <tr>
		<td style=" position:absolute; top:100px; left:35%;"><input type="text" name="plate" placeholder="  Enter Number Plate" size="50%" style="height:30px; width:150px; border-radius:45px;  border-style:none; font-size:15px; position:absolute; top:360px; left:300px "></td>
        
        <td style=" position:absolute; top:100px; left:35%;"><input type="text" name="model" placeholder="  Enter Vehicle Model" size="50%" style="height:30px; width:150px; border-radius:45px;  border-style:none; font-size:15px; position:absolute; top:360px; left:500px "></td>
        
         <td style=" position:absolute; top:100px; left:35%;"><input type="text" name="aid" placeholder="  Enter Appointment ID" size="50%" style="height:30px; width:160px; border-radius:45px;  border-style:none; font-size:15px; position:absolute; top:360px; left:850px "></td>
        
        
        <td style="font-size:1em; color:#3b3b3b; border-radius:5px; padding:1px px; font-family: 'bebas_neueregular'; position:absolute; top:363px; left:670px" name="vehicletype"> <input type="text" name="type" placeholder="  Enter Vehicle Type" size="50%" style="height:30px; width:160px; border-radius:45px;  border-style:none; font-size:15px; position:absolute; top:360px; left:670px "></td><!--option value="TYPE">Bike</option> <option value="Greater">Car</option> <option value="Lesser">Van</option> <option selected value="Andean">Lorry</option> <option value="Chilean">Three Weel</option> <option value="James's">other</option>  </select-->

        
        
        <tr>
       
</tr>

        <tr>
		<td style=" position:absolute; top:130%; left:35%;"><input type="text" name="eid" placeholder="  Enter Employee ID" size="50%" style="height:30px; border-radius:45px;  border-style:none; font-size:15px; position:absolute; top:480px; left:300px "></td>
		</tr>

        
		</tr>
        
        </div>   
        
<div>		 
<p style="font-size:1.5em; color:#E5B840; padding:1px px; font-family: 'bebas_neueregular'; position:absolute; top:440px; left:80px">Time Estimated(Hours)</style></p>
<p style="font-size:1.5em; color:#E5B840; padding:1px px; font-family: 'bebas_neueregular'; position:absolute; top:400px; left:80px">REPAIR DETAILS</style></p>
<p style="font-size:1.5em; color:#E5B840; padding:1px px; font-family: 'bebas_neueregular'; position:absolute; top:360px; left:80px">VEHICLE DETAILS</style></p>
<p style="font-size:1.5em; color:#E5B840; padding:1px px; font-family: 'bebas_neueregular'; position:absolute; top:480px; left:80px">EMPLOYEE ID</style></p>
</div>
<div style="font-size:2em; color:#E5B840; padding:200px 20px; font-family: 'bebas_neueregular'; ">

<!--img src="Garage/images/tabel1.jpg" alt="" width="1000" height="476" style=" position:absolute; bottom:-450px; right:150px;"/>

<tr>
		<td style=" position:absolute; top:170%; left:35%;"><input type="submit" name="assignbutton" value="Assign Job" style="background-color:black; color:white; width:100px; height:40px; border-radius:45px; border-style:none; position:absolute; bottom:-520px; right:150px;" ></td>
</tr-->
        
<!--tr>
		<td style=" position:absolute; top:170%; left:35%;"><input type="submit" name="cancelbutton" value="Cancel" style="background-color:grey; color:black; width:100px; height:30px; border-radius:45px; border-style:none;position:absolute; bottom:-520px; right:260px;"></td>
		</tr>
        
        <fieldset class="date">
          <select id="month_start" 
          name="month_start" style="font-size:0.5em; border-radius:5px; color:#3b3b3b; padding:1px px; font-family: 'bebas_neueregular'; position:absolute; top:440px; left:310px"/>
          
          <option>January</option>
          <option>February</option>
          <option>March</option>
          <option>April</option>
          <option>May</option>
          <option>June</option>
          <option>July</option>
          <option>August</option>
          <option>September</option>
          <option>October</option>
          <option>November</option>
          <option>December</option>
          </select>
          
  
  <select id="day_start" 
          name="day_start" style="font-size:0.5em; color:#3b3b3b; border-radius:5px; padding:1px px; font-family: 'bebas_neueregular'; position:absolute; top:440px; left:400px"/>
  
  <option>1</option>
  <option>2</option>
  <option>3</option>
  <option>4</option>
  <option>5</option>
  <option>6</option>
  <option>7</option>
  <option>8</option>
  <option>9</option>
  <option>10</option>
  <option>11</option>
  <option>12</option>
  <option>13</option>
  <option>14</option>
  <option>15</option>
  <option>16</option>
  <option>17</option>
  <option>18</option>
  <option>19</option>
  <option>20</option>
  <option>21</option>
  <option>22</option>
  <option>23</option>
  <option>24</option>
  <option>25</option>
  <option>26</option>
  <option>27</option>
  <option>28</option>
  <option>29</option>
  <option>30</option>
  <option>31</option>
  </select>
          
 
  <select id="year_start" 
         name="year_start" style="font-size:0.5em; border-radius:5px;  color:#3b3b3b; padding:1px px; font-family: 'bebas_neueregular'; position:absolute; top:440px; left:450px"/>
  
  <option>2017</option>
  <option>2018</option>
  <option>2019</option>
  <option>2020</option>
  <option>2021</option>
  <option>2022</option>
  <option>2023</option>
  <option>2024</option>
  <option>2025</option>
  <option>2026</option>
  </select>
  <!--span class="inst" style="font-size:0.5em; color:#E5B840; padding:1px px; font-family: 'bebas_neueregular'; position:absolute; top:443px; left:510px">( Month-Day-Year )</span> 
 -->     
	  </fieldset>
   
   <!--td style=" position:absolute; top:170%; left:35%;"><input type="submit" name="assignbutton" value="Print" style="background-color:black; color:white; width:100px; height:30px; border-radius:0px; border-style:none; position:absolute; bottom:-520px; right:950px;" ></td>
   <td style=" position:absolute; top:170%; left:35%;">&nbsp;</td-->
       
       
       <div>		 
<p style="font-size:0.5em; color:#9d9d9d; padding:1px px; font-family: 'bebas_neueregular'; position:absolute; top:340px; left:880px">Appointment ID</style></p>
<p style="font-size:0.5em; color:#9d9d9d; padding:1px px; font-family: 'bebas_neueregular'; position:absolute; top:340px; left:700px">Vehicle Type</style></p>
<p style="font-size:0.5em; color:#9d9d9d; padding:1px px; font-family: 'bebas_neueregular'; position:absolute; top:340px; left:560px">Model</style></p>
<p style="font-size:0.5em; color:#9d9d9d; padding:1px px; font-family: 'bebas_neueregular'; position:absolute; top:340px; left:320px">Number Plate</style></p>
</div>

<!--select style="font-size:0.5em; color:#3b3b3b; border-radius:5px; padding:1px px; font-family: 'bebas_neueregular'; position:absolute; top:440px; left:740px" name="vehicletype"> <option value="TYPE">AM</option> <option value="Greater">PM</option></select>
-->
<td style=" position:absolute; top:100px; left:20px;"><input type="text" name="etime" placeholder="  Enter Time" size="50%" style="height:20px; width:80px; border-radius:45px;  border-style:none; font-size:15px; position:absolute; top:440px; left:300px "></td>
 </form>      
</body>
</html>


<?php
include('jobassignphp.php');
//include('int-send_sms.php');
//session_start();
if($_SERVER['REQUEST_METHOD']=='POST')
{
	if(isset($_POST['assign']))
	{
		$plate=$_POST['plate'];
		$et=$_POST['etime'];
		$model=$_POST['model'];
		$type=$_POST['type'];
		$eid=$_POST['eid'];
		$aid=$_POST['aid'];
		$des=$_POST['des'];
		
		if(empty($plate)||empty($et)||empty($model)||empty($type)||empty($eid)||empty($aid)||empty($des))
		{
			echo"<script>alert('One or more fields are empty')</script>";
		}
		else if(!is_numeric($et))
		{
			echo"<script>alert('Non numeric value entered for estimated time')</script>";
		}
			
		else if(!preg_match("/^[a-zA-Z]{3}[0-9]{4}$/",$plate) && !preg_match("/^[a-zA-Z]{2}[0-9]{4}$/",$plate) && !preg_match("/^[0-9]{2}-[0-9]{4}$/",$plate) && !preg_match("/^[0-9]{3}-[0-9]{4}$/",$plate) )//plate validation here.................. 
		{
			//echo "lkldadasdadasaks";
			echo"<script>alert('Invalid Plate Number')</script>";
		}
		
		else
		{
			$aj=new AssignJob();
			$aj->assign($plate,$et,$model,$type,$eid,$aid,$des);
			
			
			/*$con=mysqli_connect("localhost","root","","garage_management_system");
			$query="SELECT jobId  FROM job ORDER BY jobId DESC LIMIT 1";
			$result=mysqli_query($con,$query);
			$row=mysqli_fetch_array($result);
			$jid=$row[0];
				
			$val='J00'.($jid+1);
			
			$query="SELECT mobile FROM employee WHERE EMPID='$eid'";
			$result=mysqli_query($con,$query);
			$row=mysqli_fetch_array($result);
			$phn=$row[0];
			
			
			$_SESSION["jid"]=$val;
			$_SESSION["pno"]=$_POST['plate'];
			$_SESSION["phn"]=$phn;*/
			
			
		}
	}
}
?>

<?php
include('UserM.php');
if($_SERVER['REQUEST_METHOD']=='POST')
{
	if(isset($_POST['logout']))
	{
		$lg=new User();
		$lg->logout();
	}
}
?>
